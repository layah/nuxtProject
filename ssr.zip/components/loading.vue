<template lang="html">
  <div v-if="loading"
       class="loading-page"
       v-loading="loading2"
       element-loading-text="发会呆，马上就好……"
       element-loading-spinner="el-icon-loading"
       element-loading-background="rgba(0, 0, 0, 0.8)">
  </div>
</template>

<script>
  export default {
    name:'loading',
    data: () => ({
      loading: false,
      loading2: true
    }),
    methods: {
      start () {
        this.loading = true
      },
      finish () {
        this.loading = false
      }
    }
  }
</script>

<style scoped>
  .loading-page {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.8);
    text-align: center;
    padding-top: 200px;
    font-size: 30px;
    font-family: sans-serif;
    z-index: 99999999;
  }
</style>
