<template>
  <div>
    <nuxt/>
  </div>
</template>
<style>
  html,body{
    margin: 0;
    height: 100%;
  }
  *{
    box-sizing: border-box;
  }
</style>
