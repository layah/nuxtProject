# ssr

> 基于vue的ssr案例

## Build Setup

``` bash
# 安装依赖包 （建议安装yarn管理包）
$ npm install # Or yarn install

# 启动开发模式，默认端口3000
$ npm run dev

# 服务器部署步骤
$ npm run build
$ npm start

# 打包静态资源
$ npm run generate
```

For detailed explanation on how things work, checkout the [Nuxt.js docs](https://github.com/nuxt/nuxt.js).
